A LaTeX template for Master's and Ph.D. thesis. The template consist of a logo, and imagefile, a KUstyle.sty file and a main.tex file.

IMPORTANT! In order for the document to compile, one needs to use XeLaTeX or LuaLaTeX as compiler. This can be done in  Overleaf by Menu -> Settings -> Compiler -> Choose XeLaTeX/LuaLaTeX

To change the content of the frontpage, ones needs to change the following commands in the document-environment:

'title' title of the project.
'subtitle' subtitle of the project.
'name' the name
'ptype' the title above the name. This document specifies the type of thesis/project.
'date' the date.
'advisor' the advisor.
'fpimage' The image on the frontpage. Remove the command if no image is desired
